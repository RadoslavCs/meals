import 'package:flutter/material.dart';
//import 'package:meals/models/filter.dart';

class FiltersScreen extends StatefulWidget {
  const FiltersScreen({super.key});

  @override
  State<FiltersScreen> createState() => _FiltersScreenState();
}

class _FiltersScreenState extends State<FiltersScreen> {
  var _glutenFreeFilterSet = false;
  var _lactoseFreeFilterSet = false;
  var _vegetarianFilterSet = false;
  var _veganFilterSet = false;

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false, // zablokuje automatické zatvorenie
      onPopInvokedWithResult: (bool didPop, dynamic result) {
        if (didPop) return; // ak už prebieha zatváranie, nič nerobíme

        // odoslanie filtrov späť do TabsScreen
        Navigator.of(context).pop({
          Filter.glutenFree: _glutenFreeFilterSet,
          Filter.lactoseFree: _lactoseFreeFilterSet,
          Filter.vegetarian: _vegetarianFilterSet,
          Filter.vegan: _veganFilterSet,
        });
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('Your Filters')),
        body: Column(
          children: [
            // ... SwitchListTile widgety (Gluten, Lactose, Vegetarian, Vegan)
          ],
        ),
      ),
    );
  }
}
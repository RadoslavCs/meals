import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'screens/categories.dart'; // hlavná obrazovka
import 'screens/meals.dart'; // import kvôli navigácii
import 'data/dummy_data.dart'; // dáta s jedlami
import 'package:meals/screens/tabs.dart';

final theme = ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(
    brightness: Brightness.dark,
    seedColor: const Color.fromARGB(255, 131, 57, 0),
  ),
  textTheme: GoogleFonts.latoTextTheme(),
);

void main() {
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Meals App',
      theme: ThemeData(useMaterial3: true), 
      home: const TabsScreen(), 
    );
  }
}
import 'package:flutter/material.dart';
import 'package:meals/models/category.dart';
import 'package:meals/models/meal.dart';

const availableCategories = [
  Category(id: 'c1', title: 'Tradičné jedlá', color: Color(0xFFFF6F91)), 
  Category(id: 'c2', title: 'Rýchle & Jednoduché', color: Color(0xFFFF9671)), 
  Category(id: 'c3', title: 'Cestoviny & Rizotá', color: Color(0xFFFFC75F)), 
  Category(id: 'c4', title: 'Polievky', color: Color(0xFFF9F871)), 
  Category(id: 'c5', title: 'Zdravé & Fit', color: Color(0xFFB5E48C)), 
  Category(id: 'c6', title: 'Dezerty', color: Color(0xFFD8BBFF)), 
  Category(id: 'c7', title: 'Raňajky', color: Color(0xFFFFA6C9)), 
  Category(id: 'c8', title: 'Medzinárodné', color: Color(0xFFA2C2E2)), 
  Category(id: 'c9', title: 'Bez mäsa', color: Color(0xFFFF8C94)), 
  Category(id: 'c10', title: 'Letné jedlá', color: Color(0xFFFFD6A5)), 
];

const dummyMeals = [
  Meal(
    id: 'm1',
    categories: ['c1', 'c2'],
    title: 'Spaghetti with Tomato Sauce',
    affordability: Affordability.affordable,
    complexity: Complexity.simple,
    imageUrl: 'https://upload.wikimedia.org/...jpg',
    duration: 20,
    ingredients: ['Tomatoes', 'Spaghetti', 'Cheese'],
    steps: ['Cut tomatoes', 'Boil water', 'Cook pasta'],
    isGlutenFree: false,
    isVegan: true,
    isVegetarian: true,
    isLactoseFree: true,
  ),
  // ďalšie jedlá...
];